# PingFangSC
PingFangSC字体包文件、苹果平方字体文件，包含`ttf`和`woff2`格式

web应用建议使用`woff2`格式的字体文件
